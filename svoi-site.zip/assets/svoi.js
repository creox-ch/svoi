/* SVOI: отправка форм сайта в Supabase (таблица svoi_submissions, только запись) */
(function(){
  var URL_ = "https://dwcmiommviauwzkhkbki.supabase.co/rest/v1/svoi_submissions";
  var KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR3Y21pb21tdmlhdXd6a2hrYmtpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODExNzA5NTMsImV4cCI6MjA5Njc0Njk1M30.7_vxB-94mpKLUSgjjODZqKBBIUKYyqrhCqrbnROfXag";
  window.SVOI_ERR = "Не получилось отправить — проверь интернет и попробуй ещё раз.";
  window.svoiSend = function(form, email, data, consent){
    return fetch(URL_, {
      method: "POST",
      headers: {"apikey": KEY, "Authorization": "Bearer " + KEY, "Content-Type": "application/json", "Prefer": "return=minimal"},
      body: JSON.stringify({form: form, email: email || null, consent: !!consent, page: location.pathname, data: data || {}})
    }).then(function(r){ if(!r.ok) throw new Error("HTTP " + r.status); return true; });
  };
})();
